package main

import "fmt"

const VERSION = "1.0.0"

func main() {
    fmt.Printf("hello, world! v%v\n", VERSION)
}
